import { FolderRouteScreen } from "@/components/workspace/projects-route-screen";

const folderNames: Record<string, string> = {
  setup: "setup",
  "n0-project1": "N0-project1",
  "n0-project2": "N0-project2",
  "n0-project3": "N0-project3",
  "n0-project4": "N0-project4",
};

type FolderPageProps = {
  params: Promise<{
    folderId: string;
  }>;
};

export default async function FolderPage({ params }: FolderPageProps) {
  const { folderId } = await params;

  return <FolderRouteScreen folderName={folderNames[folderId] ?? "setup"} />;
}
