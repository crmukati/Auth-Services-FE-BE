import { ProjectDetailRouteScreen } from "@/components/workspace/projects-route-screen";

export default async function ProjectPage({ params }: { params: Promise<{ projectId: string }> }) {
  const { projectId } = await params;

  return <ProjectDetailRouteScreen projectId={projectId} />;
}
