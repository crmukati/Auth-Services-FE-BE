"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import {
  ArrowLeft,
  ChevronDown,
  Folder,
  FolderPlus,
  Grid2X2,
  LayoutGrid,
  List,
  MoreHorizontal,
  Plus,
  Search,
  SlidersHorizontal,
  Users,
  X,
} from "lucide-react";
import { WorkspaceRouteShell } from "@/components/workspace/workspace-route-shell";

const folders = [
  { name: "setup", href: "/dashboard/projects/folders/setup" },
  { name: "N0-project1", href: "/dashboard/projects/folders/n0-project1" },
  { name: "N0-project2", href: "/dashboard/projects/folders/n0-project2" },
  { name: "N0-project3", href: "/dashboard/projects/folders/n0-project3" },
  { name: "N0-project4", href: "/dashboard/projects/folders/n0-project4" },
];

export function ProjectsRouteScreen() {
  return (
    <WorkspaceRouteShell>
      <div className="projects-route">
        <header className="projects-route__header">
          <h1>Projects</h1>
          <button type="button">
            Create
            <ChevronDown className="h-4 w-4" />
          </button>
        </header>
        <div className="projects-route__toolbar">
          <label>
            <Search className="h-4 w-4" />
            <input placeholder="Search projects..." />
          </label>
          <select defaultValue="Last edited">
            <option>Last edited</option>
          </select>
          <select defaultValue="Any visibility">
            <option>Any visibility</option>
          </select>
          <select defaultValue="Any status">
            <option>Any status</option>
          </select>
          <select defaultValue="All creators">
            <option>All creators</option>
          </select>
          <button className="active" type="button" aria-label="Filters">
            <SlidersHorizontal className="h-4 w-4" />
          </button>
          <button type="button" aria-label="Focus">
            <Grid2X2 className="h-4 w-4" />
          </button>
          <button className="active" type="button" aria-label="Grid view">
            <LayoutGrid className="h-4 w-4" />
          </button>
          <button type="button" aria-label="List view">
            <List className="h-4 w-4" />
          </button>
        </div>
        <div className="projects-route__folders">
          {folders.map((folder) => (
            <Link href={folder.href} key={folder.name}>
              <Folder className="h-5 w-5" />
              <span>{folder.name}</span>
            </Link>
          ))}
        </div>
        <p className="projects-route__empty">No projects found</p>
      </div>
    </WorkspaceRouteShell>
  );
}

export function FolderRouteScreen({ folderName }: { folderName: string }) {
  const router = useRouter();
  const [openModal, setOpenModal] = useState<"subfolder" | "existing" | null>(null);

  const createProject = () => {
    router.push(`/dashboard/projects/proj-${Date.now()}`);
  };

  return (
    <WorkspaceRouteShell activeFolder={folderName}>
      <div className="folder-route">
        <header className="folder-route__header">
          <Link href="/dashboard/projects" aria-label="Back to projects">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <Folder className="h-6 w-6" />
          <h1>{folderName}</h1>
          <button type="button" aria-label="Folder actions">
            <MoreHorizontal className="h-5 w-5" />
          </button>
        </header>
        <div className="folder-route__empty">
          <Folder className="h-16 w-16" />
          <h2>This folder is empty</h2>
          <p>Create new projects, add existing ones, or create subfolders to organize your work.</p>
          <div>
            <button className="primary" type="button" onClick={createProject}>
              <Plus className="h-4 w-4" />
              New project
            </button>
            <button type="button" onClick={() => setOpenModal("existing")}>
              <Plus className="h-4 w-4" />
              Add existing
            </button>
            <button type="button" onClick={() => setOpenModal("subfolder")}>
              <Folder className="h-4 w-4" />
              Create subfolder
            </button>
          </div>
        </div>
        {openModal === "subfolder" ? (
          <CreateSubfolderModal folderName={folderName} onClose={() => setOpenModal(null)} />
        ) : null}
        {openModal === "existing" ? <AddExistingProjectsModal onClose={() => setOpenModal(null)} /> : null}
      </div>
    </WorkspaceRouteShell>
  );
}

export function ProjectDetailRouteScreen({ projectId }: { projectId: string }) {
  return (
    <WorkspaceRouteShell>
      <div className="project-detail-route">
        <header className="folder-route__header">
          <Link href="/dashboard/projects" aria-label="Back to projects">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <LayoutGrid className="h-6 w-6" />
          <h1>{projectId}</h1>
          <button type="button" aria-label="Project actions">
            <MoreHorizontal className="h-5 w-5" />
          </button>
        </header>
        <section className="project-detail-route__center">
          <LayoutGrid className="h-14 w-14" />
          <h2>Project created</h2>
          <p>Your new project is ready in this workspace.</p>
        </section>
      </div>
    </WorkspaceRouteShell>
  );
}

function CreateSubfolderModal({ folderName, onClose }: { folderName: string; onClose: () => void }) {
  return (
    <div className="workspace-modal-overlay">
      <section className="create-folder-modal create-folder-modal--subfolder" aria-label="Create subfolder">
        <button className="create-folder-modal__close" type="button" aria-label="Close create subfolder" onClick={onClose}>
          <X className="h-5 w-5" />
        </button>
        <h2>Create subfolder</h2>
        <p>
          Create a subfolder inside <span>&quot;{folderName}&quot;</span>
        </p>
        <label className="create-folder-modal__input create-folder-modal__input--focused">
          <Folder className="h-5 w-5" />
          <input autoFocus placeholder="e.g. Side Projects" />
        </label>
        <div className="create-folder-modal__visibility create-folder-modal__visibility--disabled">
          <strong>Visibility</strong>
          <span>Subfolder inherits visibility from the parent folder.</span>
          <label className="selected">
            <input checked disabled type="radio" readOnly />
            <span>
              <b>
                <Users className="h-4 w-4" />
                Workspace
              </b>
              <small>All workspace members can see and add projects to this folder</small>
            </span>
          </label>
          <label>
            <input disabled type="radio" readOnly />
            <span>
              <b>
                <FolderPlus className="h-4 w-4" />
                Personal
              </b>
              <small>Only you can see and add projects to this folder</small>
            </span>
          </label>
        </div>
        <div className="create-folder-modal__footer">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button type="button" onClick={onClose}>
            Create
          </button>
        </div>
      </section>
    </div>
  );
}

function AddExistingProjectsModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="workspace-modal-overlay">
      <section className="add-existing-modal" aria-label="Add projects to folder">
        <button className="add-existing-modal__close" type="button" aria-label="Close add projects" onClick={onClose}>
          <X className="h-5 w-5" />
        </button>
        <h2>Add projects to folder</h2>
        <p>Select projects to add to this folder. A project can only be in one folder at a time.</p>
        <label className="add-existing-modal__search">
          <Search className="h-4 w-4" />
          <input autoFocus placeholder="Search projects..." />
        </label>
        <div className="add-existing-modal__empty">
          <span>No projects in this workspace yet</span>
        </div>
        <div className="add-existing-modal__footer">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button type="button" onClick={onClose}>
            Add 0 projects
          </button>
        </div>
      </section>
    </div>
  );
}
